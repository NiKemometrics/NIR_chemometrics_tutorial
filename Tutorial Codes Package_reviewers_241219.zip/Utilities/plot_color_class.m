function plot_color_class(data, class_info, varargin)
%% Plot data colored according to given classes
% Plot all data belonging to a given class using the same color.
% 
%       PLOT_COLOR_CLASS(data, class_info, [ax_scale, colors])
% 
% Inputs:  data        = the dataset to be plotted                   [double]
%          class_info  = the class information                       [double/cell,  size(data,1)]
%          ax_scale    = axis scale  (optional)                      [double,       size(data,2)]
%          colors      = the RGB triplets of each class  (optional)  [double,       n x 3]
% 
% Output: a new plot is obtained on the last operative figure.
% 
% 
% Version 1.2 (21.03.23)
% Nicola Cavallini (nicola.cavallini@polito.it)
% 



%% Code

% check "class_info" input
if iscell(class_info)
    
    for j = 1:length(class_info)   % loop to convert all cell content to string
        if isnumeric(class_info{j})
            class_info{j} = num2str(class_info{j});
        elseif ischar(class_info{j})
            % do nothing, already a string
        end
    end
    
    class_info_u = unique(class_info);               % get unique class values
    class_info_u_double = 1:length(class_info_u);    % get unique class values
    class_info_double = nan(length(class_info),1);   % pre-allocate class_info double version
    
    for j = 1:length(class_info_double)   % loop to generate class_info as a vector of doubles
        class_info_double(j) = find(strcmp(class_info_u, class_info{j}));
    end


elseif isnumeric(class_info)
    
    class_info_u_double = unique(class_info);   % get unique class values
    class_info_u = num2cell(class_info_u_double);
    class_info_double = class_info;      % pre-allocate class_info double version
    
end



% Plot colored data
for j = 1:length(class_info_u_double)   % loop over the classes
    hold on
    
    % check if there is an axis scale
    if isempty(varargin{1})   % no axisscale input
        ax_scale = 1:size(data,2);
    else
        ax_scale = varargin{1};
    end
    
    % check if there is a color option
    if isempty(varargin{2})   % use a color palette taken from the parula colormap
        col = parula(length(class_info_u_double));   % define color palette (default: parula)
    else
        if size(varargin{2},1) ~= length(class_info_u)   % number of colors is different from the number of classes to plot
            disp('The number of colors is different from the number of classes to plot.')
        else
            if size(varargin{2},2) ~= 3
                disp('The color input must be coded with [R G B] triplets (0-255).')
            else
                col = varargin{2}/255;
            end
        end    
    end
    
    % plot
    plot(ax_scale, data(class_info_double==class_info_u_double(j),:)', 'Color', col(j,:))
    
end

% cosmetics
box on

% colorbar with class info
colormap(col)
ticks_ign = 0:(length(class_info_u)*2);
ticks_ign = ticks_ign/max(ticks_ign);
ticks = ticks_ign(2:2:end);
colorbar('Ticks', ticks, 'TickLabels',class_info_u)
