function plot_color_resp(data, response_vector, varargin)
%% Plot data colored according to a response vector
% Plot all samples in a different color using a response vector.
% 
%       PLOT_COLOR_RESP(data, response_vector, [ax_scale, colormap, colorbar])
% 
% Inputs:  data             = the dataset to be plotted                              [double]
%          response_vector  = the response vector                                    [double, n x 1]
%          ax_scale         = the data axis scale                       (optional)   [double, size(data,2)]
%          colormap         = the name of the desired MATLAB colormap   (optional)   [string]
%          colorbar         = plot the colorbar (1) or not (0)          (optional)   [double, 0 or 1]
% 
% Output: a new figure is plotted, on the last active figure window
% 
% 
% Version 2.0 (03.03.23)
% Nicola Cavallini (nicola.cavallini@polito.it)
% 



%% Code

% Check VARARGIN
if length(varargin) < 3
    varargin = [varargin cell(1,3-length(varargin))];   % add empty cells (there must be a way to avoid this trick)
else
    % all three optional inputs were included
end


% Check the AXIS SCALE option
if isempty(varargin{1})   % no axis scale is inputed
    ax_scale = 1:size(data,2);
else
    ax_scale = varargin{1};
end


% Check the COLORMAP options (adapted from the official MATLAB colormap settings)
allowed_colormaps = [{'parula', 'Starts at dark blue and transitions to lighter blue, green, orange and yellow. The transitions between colors are more perceptually uniform than in most other colormaps.'}; ...
                     {'turbo',  'Starts at dark blue and transitions to lighter blue, bright green, orange, yellow, and dark red. This colormap is similar to jet, but the transitions between colors are more perceptually uniform than in jet.'}; ...
                     {'hsv',    'Starts at red and transitions to yellow, bright green, cyan, dark blue, magenta, and bright orange.'}; ...
                     {'hot',    'Starts at dark red and transitions to bright red, orange, yellow, and white.'}; ...
                     {'cool',   'Starts at cyan and transitions to light blue, light purple, and magenta.'}; ...
                     {'spring', 'Starts at magenta and transitions to pink, light orange, and yellow.'}; ...
                     {'summer', 'Starts at medium green and transitions to yellow.'}; ...
                     {'autumn', 'Starts at bright orange and transitions to yellow.'}; ...
                     {'winter', 'Starts at dark blue and transitions to bright green.'}; ...
                     {'gray',   'Starts at black and transitions to white.'}; ...
                     {'bone',   'Has colors that are approximately gray with a slight blue color tint. Starts at dark gray and transitions to white.'}; ...
                     {'copper', 'Starts at black and transitions to a medium orange, similar to the color of copper.'}; ...
                     {'pink',   'Starts at dark red and transitions to dark pink, tan, and white.'}; ...
                     {'jet',    'Starts at dark blue and transitions to light blue, bright green, orange, yellow, and dark red.'}];

if isempty(varargin{2})   % set default colormap: parula
    cm = colormap('parula');                                                                           % pick the parula colormap
    cm = interp1(linspace(min(response_vector),max(response_vector),length(cm)),cm,response_vector);   % map color to response values

else   % set user's desired colormap
    if ischar(varargin{2}) % the name of a specific MATLAB colormap is inputed
        
        % first, check whether the input is allowed (i.e., the colormap exists)
        if isempty(find(strcmp(allowed_colormaps(:,1), lower(varargin{2}))))   % no match with the "allowed" list was found
            error('    Please input a valid MATLAB colormap.')
            
        else   % a match was found, use that colormap
            cm = colormap(lower(varargin{2}));                                                                 % pick the selected colormap
            cm = interp1(linspace(min(response_vector),max(response_vector),length(cm)),cm,response_vector);   % map color to response values
            
        end
        
    elseif isnumeric(varargin{2})
        
        % check if the RGB dimensions are correct
        if size(varargin{2},2) == 3   % RGB requires three columns
            
            % check if the number rows matches the number of samples
            if size(varargin{2},1) == size(data,1)
                
                cm = varargin{2};   % define colormap
                
                % check if the colormap is already in the range 0-1
                if max(cm(:)) > 1
                    cm = cm/255;
                else
                    % do nothing, life is fine
                end
                
            else
                error(['    The number of colormap shades does not match the number of samples in the data (' num2str(size(data,1)) ') to plot.'])
                
            end
            
        else
            error('    Please input a valid colormap: three columns (RGB) are required as an input colormap matrix.')
        end
        
    else
        error('    Please input a valid colormap.')
    end
    
end


% PLOT the data
H = plot(ax_scale,data');   % plot and capture the line objects

% Change colors of the line objects (the samples)
for j = 1:length(response_vector)
    H(j).Color = cm(j,:);
end

% Add colorbar?
if isempty(varargin{3}) || varargin{3} == 1   % plot the colorbar (empty = use default, 1 = plotting was selected)
    colorbar
    set(gca, 'clim', [min(response_vector) max(response_vector)]);
elseif ~isempty(varargin{3}) || varargin{3} == 0   % do not plot the colorbar
end
