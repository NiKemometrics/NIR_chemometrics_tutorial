function select_toolbox(toolbox_tag)
%% Milano QSAR Toolbox selection function
% 
%    SELECT_TOOLBOX(toolbox_tag)
% 
% Valid inputs: 'pca', 'reg', 'class'
% 
% As the "PCA", "regression" and "classification" toolboxes by the QSAR and
% Chemometrics research group of Milano* may not work properly due to path
% interferences, this tool allows to select and start a session with one of
% the toolboxes while avoiding the path issue.
% 
% This is done by moving to the top of path the selected toolbox using the
% "addpath" function, which "adds the specified folders to the top of the 
% search path for the current MATLAB® session".
% (source: https://www.mathworks.com/help/matlab/ref/addpath.html)
% 
% This path change is only valid for the current MATLAB session!
% Upon reopening MATLAB the path is reverted to the user's default order.
% 
% (* https://michem.unimib.it/download/matlab-toolboxes/)
% 



%% History
% 200920 NC - v1.0
% 210920 NC - v1.1 - changed the slash "/" to filesep, a function
%                           that delivers the correct slash depending on
%                           the computer system (for compatibility with
%                           MacOS).
% 300621 NC - v2.0 - adapted to be able to choose the most recent
%                           version of the regression toolbox (v1.3)
% 230322 NC - v2.1 - now only including version 1.3 of the
%                           regression toolbox
% 040522 NC - v2.2 - cosmetics and checks ;)
% 170323 NC -(v2.2)- help cosmetics (made it simpler, History is no more
%                    printed in the Command Window with the help)
% 



%% The Selector -----------------------------------------------------------

% 0) Definitions
tags_allowed = [{'pca'}, {'reg'}, {'class'}];


% 1) Get the toolboxes' paths
path_pca   = which('pca_gui');
path_reg   = regexprep(which('reg_gui'),'1.0','1.3');
path_class = which('class_gui');


% 2) Shorthen the paths (as they include the name of the gui function)
path_pca   = path_pca(1:end-10);
path_reg   = path_reg(1:end-10);
path_class = path_class(1:end-12);


% 3) Change Matlab's path according to the chosen toolbox and start an
%    istance of the toolbox
if strcmp(toolbox_tag, tags_allowed{1}) == 1   % case: pca
    addpath(path_pca)
    addpath([path_pca filesep 'help'])
    pca_gui

elseif strcmp(toolbox_tag, tags_allowed{2}) == 1   % case: regression
    addpath(path_reg)
    addpath([path_reg filesep 'help'])
    reg_gui
    
elseif strcmp(toolbox_tag, tags_allowed{3}) == 1   % case: classification
    addpath(path_class)
    addpath([path_class filesep 'help'])
    class_gui
    
else
    error('Selection tag not recognized. Please use one of the three options: ''pca'', ''reg'', ''class''')

end
