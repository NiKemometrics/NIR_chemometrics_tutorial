%% Apply standard normal variate (SNV) to the smoothed data
NIR_data_sm31_SNV = SNV(NIR_data_sm31);   % apply Standard Normal Variate 
                                          % preprocessing using the "SNV" function 
                                          % provided in the tutorial's scripts

% Apply mean center to the smoothed and SNV data
NIR_data_sm31_SNV_mc = meancenter(NIR_data_sm31_SNV);   % apply mean center using 
                                                        % the "meancenter" function 
                                                        % provided in the tutorial's
                                                        % scripts