%% Apply a light smoothing (with Savitzky-Golay method) to the data
NIR_data_sm9  = smoothdata(NIR_data, 2, 'sgolay', 9);    % smooth data (window = 9)
NIR_data_sm31 = smoothdata(NIR_data, 2, 'sgolay', 31);   % smooth data (window = 31)

% Plot and compare the different levels of smoothing
figure

% plot the raw data
subplot(3,1,1), plot(NIR_scale_num, NIR_data')
title('raw data')
set(gca,'xdir','rev', 'XLim',[4500 5500], 'YLim',[0.5 1.8])
%                     'XLim' and 'YLim' set the horizontal and vertical
%                     intervals in of the desired zoom into the plot

% plot the smoothed data with window = 9
subplot(3,1,2), plot(NIR_scale_num, NIR_data_sm9')
title('smoothed data (window = 9 pts)')
set(gca,'xdir','rev', 'XLim',[4500 5500], 'YLim',[0.5 1.8])

% plot the smoothed data with window = 31
subplot(3,1,3), plot(NIR_scale_num, NIR_data_sm31')
title('smoothed data (window = 31 pts)')
set(gca,'xdir','rev', 'XLim',[4500 5500], 'YLim',[0.5 1.8])

xlabel('wavenumber (cm^-^1)')    % add x-label