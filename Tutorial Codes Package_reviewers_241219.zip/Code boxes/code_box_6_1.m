%% Plot potential outlier against the whole dataset

figure   % open new figure

% plot the whole dataset in grey on the figure
plot(NIR_scale_num, NIR_data_sm31_SNV', 'Color',[0.7 0.7 0.7])
                                              % [0.7 0.7 0.7] = RGB values for a light shade of grey

% plot the potential outlier in red
hold on   % keep what was already plotted and overimpose the following plotting command
plot(NIR_scale_num, NIR_data_sm31_SNV(148,:)', 'Color','r')   % 'r' means color in red
 
set(gca, 'XGrid','on', 'xdir','rev'), box on
xlabel('wavenumber (cm^-^1)')