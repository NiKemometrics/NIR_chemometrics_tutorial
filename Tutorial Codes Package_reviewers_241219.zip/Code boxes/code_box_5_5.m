%% Preprocessing - plot the datasets for inspection
figure

% 1) Plot the smooth + SNV + mean center data, colored according to percentage of arginine
subplot(3,1,1)
plot_color_resp(NIR_data_sm31_SNV_mc, resp_perc_A, NIR_scale_num, '', 1)
title('Preprocessed data: percentage (%) of arginine')
set(gca, 'XGrid','on', 'xdir','rev'), box on
h = colorbar; h.Location = 'east';   % get the colorbar's handle and move it within the plot

% 2) Plot the smooth + SNV + mean center data, colored according to percentage of sucrose
subplot(3,1,2)
plot_color_resp(NIR_data_sm31_SNV_mc, resp_perc_S, NIR_scale_num, '', 1)
title('Preprocessed data: percentage (%) of sucrose')
set(gca, 'XGrid','on', 'xdir','rev'), box on
h = colorbar; h.Location = 'east';   % get the colorbar's handle and move it within the plot

% 3) Plot the smooth + SNV + mean center data, colored according to the water content
subplot(3,1,3)
plot_color_resp(NIR_data_sm31_SNV_mc, resp_KF, NIR_scale_num, '', 1)
title('Preprocessed data: water content (KF)')
set(gca, 'XGrid','on', 'xdir','rev'), box on
h = colorbar; h.Location = 'east';   % get the colorbar's handle and move it within the plot

xlabel('wavenumber (cm^-^1)')    % add x-label
clear h                          % clean up a bit