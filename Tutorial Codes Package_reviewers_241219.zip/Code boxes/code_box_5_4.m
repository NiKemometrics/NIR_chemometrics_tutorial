%% Preprocessing - plot the preprocessing steps
figure

% 1) Plot the smoothed data
subplot(3,1,1)
plot(NIR_scale_num, NIR_data_sm31') 
title('Preprocessed data: smoothing')
set(gca, 'XGrid','on', 'xdir','rev'), box on   % 'XGrid' enables the vertical grid on the main x-axis ticks

% 2) Plot the smoothed + SNV data
subplot(3,1,2)
plot(NIR_scale_num, NIR_data_sm31_SNV')
title('Preprocessed data: smoothing + SNV')
set(gca, 'XGrid','on', 'xdir','rev'), box on

% 3) Plot the smoothed + SNV + mean centered data
subplot(3,1,3)
plot(NIR_scale_num, NIR_data_sm31_SNV_mc')
title('Preprocessed data: smoothing + SNV + mean center')
set(gca, 'XGrid','on', 'xdir','rev'), box on

xlabel('wavenumber (cm^-^1)')   % add x-label