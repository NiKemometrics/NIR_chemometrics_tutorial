%% Preprocessing - transform the raw data
NIR_data       = NIR_data_raw(:,1:690);      % reduce data removing the noisy parts
NIR_scale_num  = NIR_scale_raw_num(1:690);   % remember to cut the axis scale too!
NIR_scale_cell = num2cell(NIR_scale_num);    % this "cell" version of the axis scale 
                                             % is needed for the toolboxes used in this
                                             % tutorial

figure                                   % open a new figure

subplot(2,1,1)                           % plot in the upper part of the figure
plot(NIR_scale_raw_num, NIR_data_raw')   % plot the raw data with their scale
title('raw data')                        % add title to the subplot
set(gca,'xdir','rev')                    % revert the x-axis direction

subplot(2,1,2)                   % plot in the lower part of the figure
plot(NIR_scale_num, NIR_data')   % plot the reduced data with their scale
title('reduced data')            % add title to the subplot
set(gca,'xdir','rev')            % revert the x-axis direction 

xlabel('wavenumber (cm^-^1)')    % add x-label