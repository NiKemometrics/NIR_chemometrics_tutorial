%% Plot weird samples against the whole dataset
% define the positions of the spectra to inspect...
weird_op1 = [250:258];   % ...from operator 1
weird_op2 = [259:280];   % ...from operator 2

figure

% plot the whole dataset in grey
plot(NIR_scale_num, NIR_data_sm31_SNV', 'Color',[0.7 0.7 0.7])
                                              % [0.7 0.7 0.7] = RGB values for a light shade of grey
% plot samples from operator 1
hold on   % keep what was already plotted and overimpose the following plotting command
plot(NIR_scale_num, NIR_data_sm31_SNV(weird_op1,:)', 'Color',[128 128 255]/255)

% plot samples from operator 2
hold on
plot(NIR_scale_num, NIR_data_sm31_SNV(weird_op2,:)', 'Color',[255 128 128]/255)

set(gca, 'XGrid','on', 'xdir','rev'), box on
xlabel('wavenumber (cm^-^1)')