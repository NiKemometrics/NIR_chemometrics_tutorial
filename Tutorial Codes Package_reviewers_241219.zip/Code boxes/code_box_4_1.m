%% Read the data from Excel
[~, ~, raw_data] = xlsread('NIR_arginine_raw_data_metadata.xlsx', 'version_OK');

% Define the data objects
NIR_data_raw       = cell2mat(raw_data(2:end, 9:end));   % get raw spectra
NIR_scale_raw_cell = raw_data(1, 9:end);                 % get axis scale (wavenumbers)
NIR_scale_raw_num  = cell2mat(NIR_scale_raw_cell);       % get axis scale as numbers 
                                                         % (for plotting)
samples_labels     = raw_data(2:end,1);                  % get samples' labels

% Define the continuous metadata (response vectors)
resp_perc_A   = cell2mat(raw_data(2:end,5));   % get the percentage of arginine
resp_perc_S   = cell2mat(raw_data(2:end,6));   % get the percentage of sucrose
resp_ratio_AS = cell2mat(raw_data(2:end,7));   % get the ratio between arginine and sucrose
resp_KF       = cell2mat(raw_data(2:end,8));   % get the water content (from Karl-Fisher method)
% These response vectors are originally stored as numbers in the "raw_data"
% cell array, so they must be extracted from the cells with the "cell2mat"
% function.

% Define the discrete metadata (class vectors)
class_type = raw_data(2:end,2);   % get the class "type"
class_op   = raw_data(2:end,3);   % get the class "operator"
class_arg  = raw_data(2:end,4);   % get the class "arginine yes no"
% These class vectors are strings stored in the "raw_data" cell array, so
% no extraction from the cells is needed, we can directly take a part of
% the complete "raw_data" cell array.

clear raw_data